<?php
// Activer l'affichage des erreurs pour le debug
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once 'controllers/ProduitController.php';

$controller = new ProduitController();

// Gérer l'ajout de produit
$message = '';
if(isset($_POST['nom'])) {
    $resultat = $controller->ajouterProduit();
    if($resultat) {
        header('Location: index.php?success=1');
        exit();
    } else {
        header('Location: index.php?error=1');
        exit();
    }
}

$produits = $controller->afficherProduits();
$statistiques = $controller->afficherStatistiques();

// Définir la date d'aujourd'hui comme valeur par défaut pour le formulaire
$date_aujourd_hui = date('Y-m-d');
?>

<?php require_once 'views/header.php'; ?>

<main>
    <?php require_once 'views/formulaire.php'; ?>
    <?php require_once 'views/statistiques.php'; ?>
    <?php require_once 'views/liste.php'; ?>
</main>

<?php require_once 'views/footer.php'; ?>
