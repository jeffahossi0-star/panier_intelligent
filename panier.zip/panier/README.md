# Panier Intelligent

Application web de gestion de courses et d'analyse de dépenses familiales développée en PHP natif avec architecture MVC.

## 📋 Fonctionnalités

- ✅ Ajouter des produits (nom, prix, quantité)
- ✅ Afficher la liste des produits avec calcul automatique des totaux
- ✅ Calculer le total des dépenses
- ✅ Identifier le "Top produit" (le plus acheté en quantité)
- ✅ Interface moderne et responsive
- ✅ Architecture MVC propre et sécurisée

## 🏗️ Structure du projet

```
panier/
├── config/
│   └── database.php          # Configuration de la base de données
├── models/
│   └── Produit.php           # Modèle Produit avec fonction calculTotal()
├── controllers/
│   └── ProduitController.php # Contrôleur principal
├── views/
│   ├── header.php            # En-tête HTML
│   ├── footer.php            # Pied de page HTML
│   ├── formulaire.php        # Formulaire d'ajout
│   ├── liste.php             # Liste des produits
│   └── statistiques.php      # Statistiques
├── assets/
│   └── css/
│       └── style.css         # Feuille de style
├── index.php                 # Point d'entrée principal
├── database.sql              # Script SQL de création
├── test_calculTotal.php      # Fichier de test
└── README.md                 # Documentation
```

## 🚀 Instructions de déploiement

### 1. Prérequis

- PHP 7.4 ou supérieur
- MySQL 5.7 ou supérieur
- Serveur web (Apache, Nginx)

### 2. Déploiement local (XAMPP/WAMP)

1. **Copier les fichiers** dans le dossier `htdocs/panier/`
2. **Créer la base de données** :
   ```sql
   -- Importer le fichier database.sql via phpMyAdmin
   -- Ou exécuter manuellement les commandes SQL
   ```
3. **Configurer la base de données** si nécessaire :
   - Modifier `config/database.php` avec vos identifiants
4. **Accéder à l'application** :
   - Ouvrir `http://localhost/panier/` dans votre navigateur

### 3. Déploiement sur hébergement mutualisé gratuit

#### Option 1: InfinityFree
1. Créer un compte sur [InfinityFree](https://infinityfree.net/)
2. Créer une base de données MySQL via le panneau de contrôle
3. Uploader tous les fichiers via FTP
4. Importer `database.sql` via phpMyAdmin
5. Modifier `config/database.php` avec les identifiants fournis


### 4. Configuration de la base de données

Modifier `config/database.php` :

```php
private $host = 'localhost';           // Serveur MySQL
private $db_name = 'panier_intelligent'; // Nom de la base
private $username = 'votre_utilisateur'; // Votre utilisateur
private $password = 'votre_motdepasse';  // Votre mot de passe
```

## 🧪 Tests

Pour tester la fonction `calculTotal()` :

```bash
# Accéder au fichier de test
http://votredomaine.com/test_calculTotal.php
```

Le fichier exécute 4 tests différents pour valider le fonctionnement de la fonction.

## 🔒 Sécurité

- Utilisation de PDO avec requêtes préparées
- Protection contre les injections SQL
- Échappement des données avec `htmlspecialchars()`
- Validation des entrées utilisateur

## 🎨 Personnalisation

### Modifier les couleurs
Éditer `assets/css/style.css` et modifier les variables de couleur :

```css
background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
```

### Ajouter de nouvelles fonctionnalités
1. Créer de nouvelles méthodes dans `models/Produit.php`
2. Ajouter les actions correspondantes dans `controllers/ProduitController.php`
3. Créer les vues nécessaires dans le dossier `views/`

## 📝 Notes importantes

- L'application utilise PHP natif sans framework pour une compatibilité maximale
- La structure MVC facilite la maintenance et l'évolution
- Le code est optimisé pour les hébergements mutualisés avec ressources limitées
- Tous les fichiers sont encodés en UTF-8

## 🐛 Dépannage

### Erreur de connexion à la base de données
- Vérifier les identifiants dans `config/database.php`
- S'assurer que la base de données existe
- Vérifier que l'utilisateur a les droits nécessaires

### Page blanche
- Activer l'affichage des erreurs PHP :
  ```php
  error_reporting(E_ALL);
  ini_set('display_errors', 1);
  ```
- Vérifier les logs d'erreurs du serveur

### Problèmes de permissions
- S'assurer que les dossiers ont les bonnes permissions (755)
- Vérifier que les fichiers sont accessibles en lecture (644)

