<?php
class Produit {
    private $conn;
    private $table_name = "produits";

    public $id;
    public $nom;
    public $prix;
    public $quantite;
    public $date_achat;
    public $created_at;

    public function __construct($db) {
        $this->conn = $db;
    }

    public function create() {
        $query = "INSERT INTO " . $this->table_name . " 
                  SET nom=:nom, prix=:prix, quantite=:quantite, date_achat=:date_achat, created_at=NOW()";

        $stmt = $this->conn->prepare($query);

        $this->nom = htmlspecialchars(strip_tags($this->nom));
        $this->prix = htmlspecialchars(strip_tags($this->prix));
        $this->quantite = htmlspecialchars(strip_tags($this->quantite));
        $this->date_achat = htmlspecialchars(strip_tags($this->date_achat));

        $stmt->bindParam(":nom", $this->nom);
        $stmt->bindParam(":prix", $this->prix);
        $stmt->bindParam(":quantite", $this->quantite);
        $stmt->bindParam(":date_achat", $this->date_achat);

        if($stmt->execute()) {
            return true;
        }
        return false;
    }

    public function readAll() {
        $query = "SELECT id, nom, prix, quantite, date_achat, created_at 
                  FROM " . $this->table_name . " 
                  ORDER BY date_achat DESC, created_at DESC";

        $stmt = $this->conn->prepare($query);
        $stmt->execute();

        return $stmt;
    }

    public function getTopProduit() {
        $query = "SELECT nom, SUM(quantite) as total_quantite 
                  FROM " . $this->table_name . " 
                  GROUP BY nom 
                  ORDER BY total_quantite DESC 
                  LIMIT 1";

        $stmt = $this->conn->prepare($query);
        $stmt->execute();

        return $stmt;
    }

    public function getTotalDepenses() {
        $query = "SELECT SUM(prix * quantite) as total 
                  FROM " . $this->table_name;

        $stmt = $this->conn->prepare($query);
        $stmt->execute();

        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        return $row['total'] ?? 0;
    }
}

function calculTotal($produits) {
    $total = 0;
    foreach($produits as $produit) {
        $total += $produit['prix'] * $produit['quantite'];
    }
    return $total;
}
?>
