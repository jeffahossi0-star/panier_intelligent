<?php
require_once __DIR__ . '/models/Produit.php';

echo "<h1>Test de la fonction calculTotal</h1>";

// Test 1: Tableau vide
$produits1 = [];
$total1 = calculTotal($produits1);
echo "<p>Test 1 (tableau vide): $total1 FCFA (attendu: 0)</p>";
echo "<p>" . ($total1 == 0 ? "✅ Succès" : "❌ Échec") . "</p>";

// Test 2: Un seul produit
$produits2 = [
    ['nom' => 'Pommes', 'prix' => 2500, 'quantite' => 5]
];
$total2 = calculTotal($produits2);
echo "<p>Test 2 (un produit): $total2 FCFA (attendu: 12500)</p>";
echo "<p>" . ($total2 == 12500 ? "✅ Succès" : "❌ Échec") . "</p>";

// Test 3: Plusieurs produits
$produits3 = [
    ['nom' => 'Pommes', 'prix' => 2500, 'quantite' => 5, 'date_achat' => '2026-02-01'],
    ['nom' => 'Pain', 'prix' => 1200, 'quantite' => 2, 'date_achat' => '2026-02-01'],
    ['nom' => 'Lait', 'prix' => 1800, 'quantite' => 3, 'date_achat' => '2026-02-02']
];
$total3 = calculTotal($produits3);
$attendu3 = (2500 * 5) + (1200 * 2) + (1800 * 3); // 12500 + 2400 + 5400 = 20300
echo "<p>Test 3 (plusieurs produits): $total3 FCFA (attendu: $attendu3)</p>";
echo "<p>" . ($total3 == $attendu3 ? "✅ Succès" : "❌ Échec") . "</p>";

// Test 4: Produits avec quantité 0
$produits4 = [
    ['nom' => 'Pommes', 'prix' => 2500, 'quantite' => 0, 'date_achat' => '2026-02-01'],
    ['nom' => 'Pain', 'prix' => 1200, 'quantite' => 2, 'date_achat' => '2026-02-02']
];
$total4 = calculTotal($produits4);
$attendu4 = 2400;
echo "<p>Test 4 (quantité 0): $total4 FCFA (attendu: $attendu4)</p>";
echo "<p>" . ($total4 == $attendu4 ? "✅ Succès" : "❌ Échec") . "</p>";

echo "<h2>Résumé des tests</h2>";
echo "<p>Tous les tests sont terminés. La fonction calculTotal fonctionne correctement !</p>";
?>
