<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Test des messages - Panier Intelligent</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <div class="container">
        <header>
            <h1>🧪 Test des Messages</h1>
            <p>Page de test pour visualiser tous les types de messages</p>
        </header>
        
        <main>
            <section class="formulaire-section">
                <h2>Messages de test</h2>
                
                <!-- Message de succès -->
                <div class="alert success" id="successMessage">
                    <div>
                        <strong>🎉 Succès !</strong><br>
                        <small>Le produit a été ajouté à votre panier intelligent</small>
                    </div>
                </div>
                
                <!-- Message d'erreur -->
                <div class="alert error" id="errorMessage">
                    <div>
                        <strong>⚠️ Erreur !</strong><br>
                        <small>Impossible d'ajouter le produit. Veuillez réessayer.</small>
                    </div>
                </div>
                
                <div style="margin-top: 30px; padding: 20px; background: #f7fafc; border-radius: 8px;">
                    <h3>🔗 Liens de test rapides</h3>
                    <p>Cliquez sur ces liens pour voir les messages dans le contexte réel :</p>
                    <ul>
                        <li><a href="index.php?success=1" style="color: #38a169;">Message de succès dans l'application</a></li>
                        <li><a href="index.php?error=1" style="color: #e53e3e;">Message d'erreur dans l'application</a></li>
                        <li><a href="index.php" style="color: #667eea;">Retour à l'application</a></li>
                    </ul>
                </div>
                
                <div style="margin-top: 20px; padding: 15px; background: #fef5e7; border-radius: 8px; border-left: 4px solid #f39c12;">
                    <h4>💡 Notes sur les messages</h4>
                    <ul>
                        <li><strong>Succès</strong> : Disparaît automatiquement après 4 secondes</li>
                        <li><strong>Erreur</strong> : Disparaît automatiquement après 6 secondes</li>
                        <li><strong>Animations</strong> : Apparition et disparition fluides</li>
                        <li><strong>Design</strong> : Dégradés modernes avec effets visuels</li>
                    </ul>
                </div>
            </section>
        </main>
        
        <footer>
            <p>&copy; 2026 Panier Intelligent - Page de test des messages</p>
        </footer>
    </div>
    
    <script>
        // Simuler la disparition automatique des messages
        setTimeout(() => {
            const successMsg = document.getElementById('successMessage');
            if(successMsg) {
                successMsg.style.animation = 'slideOut 0.5s ease-out forwards';
                setTimeout(() => successMsg.remove(), 500);
            }
        }, 4000);
        
        setTimeout(() => {
            const errorMsg = document.getElementById('errorMessage');
            if(errorMsg) {
                errorMsg.style.animation = 'slideOut 0.5s ease-out forwards';
                setTimeout(() => errorMsg.remove(), 500);
            }
        }, 6000);
    </script>
</body>
</html>
