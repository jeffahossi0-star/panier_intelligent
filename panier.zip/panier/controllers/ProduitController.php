<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../models/Produit.php';

class ProduitController {
    private $db;
    private $produit;

    public function __construct() {
        $database = new Database();
        $this->db = $database->getConnection();
        $this->produit = new Produit($this->db);
    }

    public function ajouterProduit() {
        if($_SERVER['REQUEST_METHOD'] == 'POST') {
            $this->produit->nom = $_POST['nom'];
            $this->produit->prix = $_POST['prix'];
            $this->produit->quantite = $_POST['quantite'];
            $this->produit->date_achat = $_POST['date_achat'];

            if($this->produit->create()) {
                return true;
            } else {
                return false;
            }
        }
    }

    public function afficherProduits() {
        $stmt = $this->produit->readAll();
        $produits = $stmt->fetchAll(PDO::FETCH_ASSOC);
        return $produits;
    }

    public function afficherStatistiques() {
        $total = $this->produit->getTotalDepenses();
        
        $topStmt = $this->produit->getTopProduit();
        $topProduit = $topStmt->fetch(PDO::FETCH_ASSOC);

        return [
            'total' => $total,
            'topProduit' => $topProduit
        ];
    }
}
?>
