<section class="statistiques-section">
    <h2>📊 Statistiques</h2>
    
    <div class="stats-grid">
        <div class="stat-card">
            <h3>Total des dépenses</h3>
            <div class="stat-value"><?= number_format($statistiques['total'], 0) ?> FCFA</div>
        </div>
        
        <div class="stat-card">
            <h3>Top produit</h3>
            <div class="stat-value">
                <?php if($statistiques['topProduit']): ?>
                    <?= htmlspecialchars($statistiques['topProduit']['nom']) ?>
                    <small>(<?= $statistiques['topProduit']['total_quantite'] ?> unités)</small>
                <?php else: ?>
                    Aucun produit
                <?php endif; ?>
            </div>
        </div>
    </div>
</section>
