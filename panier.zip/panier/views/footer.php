        <footer>
            <p>&copy; 2026 Panier Intelligent - Application de gestion de courses - Conçues par AHOSSI Jeff</p>
        </footer>
    </div>
</body>
</html>
