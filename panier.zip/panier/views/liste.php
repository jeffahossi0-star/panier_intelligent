<section class="liste-section">
    <h2>Liste des produits</h2>
    
    <?php if(empty($produits)): ?>
        <div class="empty-state">
            <p>Aucun produit ajouté pour le moment.</p>
            <p>Commencez par ajouter votre premier produit !</p>
        </div>
    <?php else: ?>
        <div class="table-container">
            <table class="produits-table">
                <thead>
                    <tr>
                        <th>Nom</th>
                        <th>Prix unitaire (FCFA)</th>
                        <th>Quantité</th>
                        <th>Total (FCFA)</th>
                        <th>Date d'achat</th>
                        <th>Ajouté le</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach($produits as $produit): ?>
                        <tr>
                            <td><?= htmlspecialchars($produit['nom']) ?></td>
                            <td><?= number_format($produit['prix'], 0) ?> FCFA</td>
                            <td><?= $produit['quantite'] ?></td>
                            <td><?= number_format($produit['prix'] * $produit['quantite'], 0) ?> FCFA</td>
                            <td><?= date('d/m/Y', strtotime($produit['date_achat'])) ?></td>
                            <td><?= date('d/m/Y H:i', strtotime($produit['created_at'])) ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
</section>
