<section class="formulaire-section">
    <h2>Ajouter un produit</h2>
    
    <!-- Liens de test pour voir les messages -->
    <div style="margin-bottom: 15px; padding: 10px; background: #f0f0f0; border-radius: 8px; font-size: 0.9rem;">
        <strong>🧪 Test rapide des messages :</strong><br>
        <a href="index.php?success=1" style="color: #38a169; text-decoration: none; font-weight: bold; margin-right: 15px;">
            ✅ Voir message de succès
        </a>
        <a href="index.php?error=1" style="color: #e53e3e; text-decoration: none; font-weight: bold;">
            ❌ Voir message d'erreur
        </a>
    </div>
    
    <?php if(isset($_GET['success'])): ?>
        <div class="alert success" id="successMessage">
            <div>
                <strong>🎉 Succès !</strong><br>
                <small>Le produit a été ajouté à votre panier intelligent</small>
            </div>
        </div>
        <script>
            setTimeout(() => {
                const msg = document.getElementById('successMessage');
                if(msg) {
                    msg.style.animation = 'slideOut 0.5s ease-out forwards';
                    setTimeout(() => msg.remove(), 500);
                }
            }, 4000);
        </script>
    <?php endif; ?>
    
    <?php if(isset($_GET['error'])): ?>
        <div class="alert error" id="errorMessage">
            <div>
                <strong>⚠️ Erreur !</strong><br>
                <small>Impossible d'ajouter le produit. Veuillez réessayer.</small>
            </div>
        </div>
        <script>
            setTimeout(() => {
                const msg = document.getElementById('errorMessage');
                if(msg) {
                    msg.style.animation = 'slideOut 0.5s ease-out forwards';
                    setTimeout(() => msg.remove(), 500);
                }
            }, 6000);
        </script>
    <?php endif; ?>

    <form action="index.php" method="POST" class="produit-form">
        <div class="form-group">
            <label for="nom">Nom du produit :</label>
            <input type="text" id="nom" name="nom" required placeholder="Ex: Pommes">
        </div>
        
        <div class="form-group">
            <label for="prix">Prix (FCFA) :</label>
            <input type="number" id="prix" name="prix" step="1" min="0" required placeholder="Ex: 2500">
        </div>
        
        <div class="form-group">
            <label for="quantite">Quantité :</label>
            <input type="number" id="quantite" name="quantite" min="1" required placeholder="Ex: 5">
        </div>
        
        <div class="form-group">
            <label for="date_achat">Date d'achat :</label>
            <input type="date" id="date_achat" name="date_achat" required value="<?= $date_aujourd_hui ?>">
        </div>
        
        <button type="submit" class="btn btn-primary">Ajouter le produit</button>
    </form>
</section>
