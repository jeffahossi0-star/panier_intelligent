-- Création de la base de données
CREATE DATABASE IF NOT EXISTS panier_intelligent;
USE panier_intelligent;

-- Création de la table produits
CREATE TABLE IF NOT EXISTS produits (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nom VARCHAR(255) NOT NULL,
    prix DECIMAL(10, 2) NOT NULL,
    quantite INT NOT NULL,
    date_achat DATE NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Insertion de données de test (optionnel)
INSERT INTO produits (nom, prix, quantite, date_achat) VALUES
('Pommes', 2500, 5, '2026-02-01'),
('Pain', 1200, 2, '2026-02-01'),
('Lait', 1800, 3, '2026-02-02'),
('Œufs', 3500, 12, '2026-02-02'),
('Fromage', 4200, 1, '2026-02-03');
