<?php
// Activer l'affichage des erreurs
error_reporting(E_ALL);
ini_set('display_errors', 1);

echo "<h1>🔍 Debug Panier Intelligent</h1>";

// Test 1: Vérifier la configuration de la base de données
echo "<h2>1. Test de connexion à la base de données</h2>";

try {
    require_once 'config/database.php';
    $database = new Database();
    $conn = $database->getConnection();
    
    if($conn) {
        echo "<p style='color: green;'>✅ Connexion à la base de données réussie</p>";
        
        // Test 2: Vérifier si la table produits existe
        echo "<h2>2. Vérification de la table produits</h2>";
        $stmt = $conn->query("SHOW TABLES LIKE 'produits'");
        if($stmt->rowCount() > 0) {
            echo "<p style='color: green;'>✅ Table 'produits' existe</p>";
            
            // Test 3: Vérifier la structure de la table
            echo "<h2>3. Structure de la table produits</h2>";
            $stmt = $conn->query("DESCRIBE produits");
            echo "<table border='1'><tr><th>Champ</th><th>Type</th><th>Null</th><th>Key</th></tr>";
            while($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                echo "<tr><td>{$row['Field']}</td><td>{$row['Type']}</td><td>{$row['Null']}</td><td>{$row['Key']}</td></tr>";
            }
            echo "</table>";
            
            // Test 4: Compter les produits existants
            echo "<h2>4. Nombre de produits dans la base</h2>";
            $stmt = $conn->query("SELECT COUNT(*) as total FROM produits");
            $result = $stmt->fetch(PDO::FETCH_ASSOC);
            echo "<p>Nombre de produits : {$result['total']}</p>";
            
            // Test 5: Afficher les produits existants
            if($result['total'] > 0) {
                echo "<h2>5. Produits existants</h2>";
                $stmt = $conn->query("SELECT * FROM produits ORDER BY created_at DESC");
                echo "<table border='1'><tr><th>ID</th><th>Nom</th><th>Prix</th><th>Quantité</th><th>Date achat</th><th>Created_at</th></tr>";
                while($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                    echo "<tr><td>{$row['id']}</td><td>{$row['nom']}</td><td>{$row['prix']}</td><td>{$row['quantite']}</td><td>{$row['date_achat']}</td><td>{$row['created_at']}</td></tr>";
                }
                echo "</table>";
            }
            
        } else {
            echo "<p style='color: red;'>❌ Table 'produits' n'existe pas</p>";
            echo "<p>Veuillez importer le fichier database.sql via phpMyAdmin</p>";
        }
        
    } else {
        echo "<p style='color: red;'>❌ Échec de la connexion à la base de données</p>";
    }
    
} catch(Exception $e) {
    echo "<p style='color: red;'>❌ Erreur : " . $e->getMessage() . "</p>";
}

// Test 6: Vérifier les permissions des fichiers
echo "<h2>6. Permissions des fichiers</h2>";
$files = [
    'config/database.php',
    'models/Produit.php',
    'controllers/ProduitController.php',
    'views/formulaire.php',
    'views/liste.php',
    'views/statistiques.php'
];

foreach($files as $file) {
    if(file_exists($file)) {
        echo "<p style='color: green;'>✅ $file existe</p>";
    } else {
        echo "<p style='color: red;'>❌ $file n'existe pas</p>";
    }
}

// Test 7: Vérifier les variables POST
echo "<h2>7. Variables POST reçues</h2>";
if($_POST) {
    echo "<pre>";
    print_r($_POST);
    echo "</pre>";
} else {
    echo "<p>Aucune donnée POST reçue</p>";
}
?>
